# Employee Attrition & Workforce Demographics Analysis

## Executive summary

- The uploaded selected-columns dataset contains **1,470 employees and 10 columns**. It has **237 employees who left**, **1,233 who stayed**, and an overall observed attrition rate of **16.12%**.

- Data quality checks found **0 missing values**, **0 duplicate rows**, and **0 duplicate EmployeeNumber values**.

- The selected file does not contain the original request’s fields for monthly income, job role, overtime, satisfaction, tenure, gender, marital status, job level, stock options, or performance ratings. The report analyzes every requested topic that is supported by available columns.

## 1. Dataset overview

- Rows: **1,470**; columns: **10**.

- Original columns: `Age, Attrition, BusinessTravel, DailyRate, Department, DistanceFromHome, Education, EducationField, EmployeeCount, EmployeeNumber`.

- Numeric columns: `Age, DailyRate, DistanceFromHome, Education, EmployeeCount, EmployeeNumber`.

- Categorical columns: `Attrition, BusinessTravel, Department, EducationField`.

- Target/outcome: `Attrition` (`Yes` = left; `No` = stayed).

### Unavailable requested columns

- MonthlyIncome / compensation fields

- JobRole

- OverTime

- JobSatisfaction, EnvironmentSatisfaction, RelationshipSatisfaction, WorkLifeBalance

- YearsAtCompany, YearsInCurrentRole, YearsSinceLastPromotion, YearsWithCurrManager, TotalWorkingYears

- Gender, MaritalStatus, JobLevel, StockOptionLevel, PerformanceRating

## 2. Data-quality audit

- Missing values: **0 total**; all original columns have 0 missing values.

- Duplicate full rows: **0**.

- Duplicate EmployeeNumber values: **0**.

- Available numeric ranges: Age 18–60; DailyRate 102–1499; DistanceFromHome 1–29; Education 1–5; EmployeeCount is constant at 1.

- No invalid or inconsistent categories were found in the available categorical fields.

## 3. Overall HR KPIs

| KPI | Actual result |

|---|---:|

| Total employees | 1,470 |

| Employees who left | 237 |

| Employees who stayed | 1,233 |

| Overall attrition rate (%) | 16.12 |

| Average age | 36.92 |

| Average daily rate | 802.49 |

| Average distance from home | 9.19 |

| Average education level | 2.91 |

| Average employee count field | 1.00 |

| Attrition-rate formula | Employees who left / total employees × 100 |

## 4. Attrition analysis

### Department

                        Employees  Left  Stayed  Attrition Rate (%)
Department                                                         
Sales                         446    92     354               20.63
Human Resources                63    12      51               19.05
Research & Development        961   133     828               13.84

### BusinessTravel

                   Employees  Left  Stayed  Attrition Rate (%)
BusinessTravel                                                
Travel_Frequently        277    69     208               24.91
Travel_Rarely           1043   156     887               14.96
Non-Travel               150    12     138                 8.0

### EducationField

                  Employees  Left  Stayed  Attrition Rate (%)
EducationField                                               
Human Resources          27     7      20               25.93
Technical Degree        132    32     100               24.24
Marketing               159    35     124               22.01
Life Sciences           606    89     517               14.69
Medical                 464    63     401               13.58
Other                    82    11      71               13.41

### Education

           Employees  Left  Stayed  Attrition Rate (%)
Education                                             
1                170    31     139               18.24
3                572    99     473               17.31
2                282    44     238                15.6
4                398    58     340               14.57
5                 48     5      43               10.42

### Age Group

           Employees  Left  Stayed  Attrition Rate (%)
Age Group                                             
Under 26         123    44      79               35.77
26-35            606   116     490               19.14
56+               47     8      39               17.02
46-55            226    26     200                11.5
36-45            468    43     425                9.19

### DailyRate Band

                Employees  Left  Stayed  Attrition Rate (%)
DailyRate Band                                             
Q1 (lowest)           369    74     295               20.05
Q2                    367    59     308               16.08
Q3                    367    56     311               15.26
Q4 (highest)          367    48     319               13.08

## 5. Department analysis

                        Employees  Left  Attrition Rate (%)  Avg_DailyRate  Avg_Age  Avg_Distance  Avg_Education
Department                                                                                                      
Human Resources                63    12               19.05         751.54    37.81           8.7           2.97
Research & Development        961   133               13.84         806.85    37.04          9.14            2.9
Sales                         446    92               20.63         800.28    36.54          9.37           2.93

## 6. Business-travel analysis

                   Employees  Left  Attrition Rate (%)  Avg_DailyRate  Avg_Age  Avg_Distance
BusinessTravel                                                                              
Non-Travel               150    12                 8.0         816.96    36.62          9.76
Travel_Frequently        277    69               24.91         792.63    36.45          9.28
Travel_Rarely           1043   156               14.96         803.02    37.09          9.09

## 7. Stayed vs left numeric comparisons

            Age                      DailyRate                          DistanceFromHome                      Education                    
          count  mean median min max     count   mean median  min   max            count  mean median min max     count mean median min max
Attrition                                                                                                                                  
No         1233 37.56   36.0  18  60      1233  812.5  817.0  102  1499             1233  8.92    7.0   1  29      1233 2.93    3.0   1   5
Yes         237 33.61   32.0  18  58       237 750.36  699.0  103  1496              237 10.63    9.0   1  29       237 2.84    3.0   1   5

## 8. Multi-factor analysis: Department × Business Travel

Attrition                                  No  Yes  Total  Attrition Rate (%)
Department             BusinessTravel                                        
Human Resources        Non-Travel           6    0      6                 0.0
                       Travel_Frequently    7    4     11               36.36
                       Travel_Rarely       38    8     46               17.39
Research & Development Non-Travel          89    8     97                8.25
                       Travel_Frequently  145   37    182               20.33
                       Travel_Rarely      594   88    682                12.9
Sales                  Non-Travel          43    4     47                8.51
                       Travel_Frequently   56   28     84               33.33
                       Travel_Rarely      255   60    315               19.05

## 9. Evidence-based insights

1. Overall observed attrition was **16.12%**: **237 of 1470 employees** left.

2. Sales had an observed attrition rate of **20.63%** (**92 of 446**), compared with **13.84%** in Research & Development (**133 of 961**).

3. Travel_Frequently had an observed attrition rate of **24.91%** (**69 of 277**), versus **14.96%** for Travel_Rarely (**156 of 1043**).

4. Non-Travel had an observed attrition rate of **8.00%** (**12 of 150**).

5. Under 26 employees had an observed attrition rate of **35.77%** (**44 of 123**), compared with **11.50%** for ages 46–55 (**26 of 226**).

6. Human Resources as an education field had an observed attrition rate of **25.93%** (**7 of 27**), while Medical was **13.58%** (**63 of 464**).

7. The highest DailyRate quartile had an observed attrition rate of **13.08%** (**48 of 367**), versus **20.05%** in the lowest quartile (**74 of 369**). This is a DailyRate association, not a monthly-income finding.

8. Employees who left had mean age **33.61** versus **37.56** among employees who stayed.

9. Employees who left had mean DistanceFromHome **10.63** versus **8.92** among employees who stayed.

## 10. Recommendations

1. Prioritize a retention review in Sales, where observed attrition is higher than in Research & Development; segment the review by travel and age because those fields are available.

2. Investigate the employee experience of frequent travelers, since Travel_Frequently has a higher observed attrition rate than Travel_Rarely; review travel load, scheduling, and support.

3. Review early-career retention for employees under 26 through onboarding, manager check-ins, and career-path discussions, based on the higher observed attrition rate in that group.

4. Use DailyRate as an internal prioritization signal only; the file does not contain MonthlyIncome or salary fields, so compensation conclusions cannot be made.

5. Capture the absent HR drivers—overtime, satisfaction, job role, tenure, promotion history, and compensation—in future extracts before making targeted interventions in those areas.

6. Monitor attrition by department and business-travel category over time using both employee counts and rates to avoid over-interpreting small groups.

## 11. Charts

- `attrition_analysis_outputs/01_overall_attrition.png`

- `attrition_analysis_outputs/02_attrition_by_department.png`

- `attrition_analysis_outputs/03_attrition_by_business_travel.png`

- `attrition_analysis_outputs/04_attrition_by_age_group.png`

- `attrition_analysis_outputs/05_attrition_by_dailyrate_quartile.png`

- `attrition_analysis_outputs/06_attrition_by_education_field.png`

- `attrition_analysis_outputs/07_age_distribution.png`

- `attrition_analysis_outputs/08_dailyrate_by_attrition.png`

- `attrition_analysis_outputs/09_distance_by_attrition.png`

- `attrition_analysis_outputs/10_employee_distribution_department.png`

- `attrition_analysis_outputs/11_employee_distribution_education_field.png`

## Limitations

- These are descriptive associations, not causal estimates.

- The selected-columns file does not support overtime, satisfaction, tenure, job role, monthly income, gender, marital status, job level, stock options, or performance-rating analyses.