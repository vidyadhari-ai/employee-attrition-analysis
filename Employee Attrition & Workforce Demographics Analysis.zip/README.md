# Employee Attrition & Workforce Demographics Analysis

## Project objective
Analyze employee attrition patterns using demographic, department, business-travel,
education and DailyRate information available in the selected HR dataset.

## Dataset
- 1,470 employee records
- 10 columns
- 237 employees left
- 1,233 employees stayed
- Observed attrition rate: 16.12%
- Missing values: 0
- Duplicate rows: 0
- Duplicate EmployeeNumber values: 0

## Key findings
- Overall observed attrition: 16.12% (237/1,470).
- Sales: 20.63% (92/446); R&D: 13.84% (133/961).
- Travel_Frequently: 24.91% (69/277); Travel_Rarely: 14.96% (156/1,043); Non-Travel: 8.00% (12/150).
- Under-26 employees: 35.77% (44/123).
- Lowest DailyRate quartile: 20.05% (74/369); highest quartile: 13.08% (48/367).
- Employees who left had mean age 33.61 versus 37.56 among those who stayed.
- Employees who left had mean DistanceFromHome 10.63 versus 8.92 among those who stayed.

## Business interpretation
These are descriptive associations, not causal findings. The selected dataset does not
contain monthly income, job role, overtime, satisfaction, tenure, promotion history,
gender, marital status, job level, stock options or performance ratings.

## Recommendations
1. Review retention patterns in Sales.
2. Examine the employee experience of frequent travelers.
3. Review early-career retention for employees under 26.
4. Treat DailyRate only as an internal analytical signal, not as a salary measure.
5. Add missing HR drivers such as overtime, satisfaction, tenure and compensation to future extracts.

## Deliverables
- `report/employee_attrition_analysis_report.md`
- `report/employee_attrition_analysis_report.pdf`
- `charts/` — 11 visualization assets
- `portfolio_description.txt` — resume/portfolio-ready project description

## Tools
Python, Pandas, Matplotlib, data cleaning, descriptive analysis and data visualization.
